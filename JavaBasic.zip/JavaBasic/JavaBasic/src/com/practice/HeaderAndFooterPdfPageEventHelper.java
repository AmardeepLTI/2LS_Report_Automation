package com.practice;

import java.awt.Rectangle;

import javax.swing.text.Document;

import com.itextpdf.kernel.pdf.PdfWriter;
import com.spire.pdf.PdfPageLayer;

class HeaderAndFooterPdfPageEventHelper extends PdfPageLayer {
		  public void onStartPage(PdfWriter pdfWriter, Document document) {
		      System.out.println("onStartPage() method > Writing header in file");
		      Rectangle rect = pdfWriter.getBoxSize("rectangle");
		      
		      // TOP LEFT
		      ColumnText.showTextAligned(pdfWriter.getDirectContent(),
		               Element.ALIGN_CENTER, new Phrase("TOP LEFT"), rect.getLeft(),
		               rect.getTop(), 0);
		 
		      // TOP MEDIUM
		      ColumnText.showTextAligned(pdfWriter.getDirectContent(),
		               Element.ALIGN_CENTER, new Phrase("TOP MEDIUM"),
		               rect.getRight() / 2, rect.getTop(), 0);
		 
		      // TOP RIGHT
		      ColumnText.showTextAligned(pdfWriter.getDirectContent(),
		               Element.ALIGN_CENTER, new Phrase("TOP RIGHT"), rect.getRight(),
		               rect.getTop(), 0);
		  }
		 
		  public void onEndPage(PdfWriter pdfWriter, Document document) {
		      System.out.println("onEndPage() method > Writing footer in file");
		      Rectangle rect = pdfWriter.getBoxSize("rectangle");
		      // BOTTOM LEFT
		      ColumnText.showTextAligned(pdfWriter.getDirectContent(),
		               Element.ALIGN_CENTER, new Phrase("BOTTOM LEFT"),
		               rect.getLeft()+15, rect.getBottom(), 0);
		 
		      // BOTTOM MEDIUM
		      ColumnText.showTextAligned(pdfWriter.getDirectContent(),
		               Element.ALIGN_CENTER, new Phrase("BOTTOM MEDIUM"),
		               rect.getRight() / 2, rect.getBottom(), 0);
		 
		      // BOTTOM RIGHT
		      ColumnText.showTextAligned(pdfWriter.getDirectContent(),
		               Element.ALIGN_CENTER, new Phrase("BOTTOM RIGHT"),
		               rect.getRight()-10, rect.getBottom(), 0);
		  }
		}


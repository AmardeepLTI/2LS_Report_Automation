package com.practice;

import java.io.IOException;

public class Basic {

	public static void main(String[] args) throws InterruptedException, IOException {

		Activity act = new Activity();
		act.logIn();
	}

}

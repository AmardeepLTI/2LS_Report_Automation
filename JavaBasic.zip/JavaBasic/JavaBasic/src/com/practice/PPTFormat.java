package com.practice;

import java.awt.Color;
import java.awt.Rectangle;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;


import org.apache.poi.util.IOUtils;
import org.apache.poi.xslf.usermodel.SlideLayout;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFPictureData;
import org.apache.poi.xslf.usermodel.XSLFPictureShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFSlideLayout;
import org.apache.poi.xslf.usermodel.XSLFSlideMaster;
import org.apache.poi.xslf.usermodel.XSLFTextParagraph;
import org.apache.poi.xslf.usermodel.XSLFTextRun;
import org.apache.poi.xslf.usermodel.XSLFTextShape;

public class PPTFormat {

public static void main (String [] args) throws Exception{
	XMLSlideShow ppt = new XMLSlideShow();
	XSLFSlideMaster defaultMaster = ppt.getSlideMasters()[0];
	
	XSLFSlideLayout layout= defaultMaster.getLayout(SlideLayout.TITLE_AND_CONTENT);
	
	XSLFSlide slide = ppt.createSlide(layout);
	
	XSLFTextShape title= slide.getPlaceholder(0);
	
	title.clearText();
	XSLFTextParagraph p= title.addNewTextParagraph();
	XSLFTextRun r= p.addNewTextRun();
	r.setText("Info Screen");
	r.setFontColor(Color.black);
	r.setFontSize(50.);
	
	InputStream is =Thread.currentThread().getContextClassLoader().getResourceAsStream("one.png");
	byte[] pd;
	try {
		pd = IOUtils.toByteArray(is);
		int pictureData= ppt.addPicture(pd,XSLFPictureData.PICTURE_TYPE_PNG);
		
		XSLFPictureShape pictureShape= slide.createPicture(pictureData);
		
		pictureShape.setAnchor(new Rectangle(20,180,680,188));
		
		FileOutputStream out = new FileOutputStream("MyPPT.pptx");
		ppt.write(out);
		out.close();
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
}

}
